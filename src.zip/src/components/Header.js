import React from "react";
import Hero from "./Hero";

function Header() {
  return (
    <>
      <div className="flex justify-between item-center mx-auto p-4 bg-black">
        <div>
          <h3 className="font-bold text-2xl text-white">Vani</h3>
        </div>
        <div className="hidden flex flex-col space-x-10 md:flex-row space-y-0 md:block">
          <a className="font-small text-xl text-white" href="">
            About
          </a>
          <a className="font-small text-xl text-white" href="">
            Work
          </a>
          <a className="font-small text-xl text-white" href="">
            Testimonials
          </a>
          <a className="font-small text-xl text-white" href="">
            Contact
          </a>
          <a className="font-small text-xl text-white" href="">
            theme
          </a>
          <a className="font-small text-xl text-white" href="">
            Download CV
          </a>
        </div>
      </div>
    </>
  );
}

export default Header;
